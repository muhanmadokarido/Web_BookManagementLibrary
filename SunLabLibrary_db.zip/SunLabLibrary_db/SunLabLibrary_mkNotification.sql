-- MySQL dump 10.13  Distrib 5.7.28, for Linux (x86_64)
--
-- Host: localhost    Database: SunLabLibrary
-- ------------------------------------------------------
-- Server version	5.7.28-0ubuntu0.18.04.4

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `mkNotification`
--

DROP TABLE IF EXISTS `mkNotification`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mkNotification` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Ass_Id` int(11) DEFAULT NULL,
  `Message` varchar(545) DEFAULT NULL,
  `Active` varchar(45) DEFAULT NULL,
  `not_dateTime` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `index2` (`Ass_Id`),
  CONSTRAINT `fk_mkNotification_1` FOREIGN KEY (`Ass_Id`) REFERENCES `lib_users` (`user_Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mkNotification`
--

LOCK TABLES `mkNotification` WRITE;
/*!40000 ALTER TABLE `mkNotification` DISABLE KEYS */;
INSERT INTO `mkNotification` VALUES (17,67,'Mruser1 Aluser1is Asking toreturn his book With Id: 17','No','16/01/2020 16:44:16'),(18,67,'Mruser1 Aluser1Lent you  book with Id: 17','No','16/01/2020 16:55:44'),(19,67,'Mruser1 Aluser1is Asking toreturn his book With Id: 17','No','16/01/2020 16:55:54'),(20,71,'Mruserx userxxLent you  book with Id: 20','No','16/01/2020 16:59:59'),(21,71,'Mruserx userxxis Asking toreturn his book With Id: 20','No','16/01/2020 17:00:11'),(22,70,'Mruser10 Alkhaledis Asking to Lend You Book With Id: 20To lend it assign the book to user1@gmail.com','No','16/01/2020 17:02:39');
/*!40000 ALTER TABLE `mkNotification` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-01-16 17:53:23
